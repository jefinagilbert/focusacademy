export const styles = {
    main : {
        width : '100%', height : '100vh', display : 'flex', justifyContent : 'center', alignItems : 'center'
    },
    form : {
        width : '600px', padding : '20px', display : 'flex', flexDirection : 'column', justifyContent : 'center',
        alignItems : 'center'
    }, 
    inputBox : {
        width : '50%'
    },
    input : {
        width : '100%'
    },
    helperTxt : {
        fontSize : '12px', color : 'red'
    }
}