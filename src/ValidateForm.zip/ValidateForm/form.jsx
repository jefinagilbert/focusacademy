import * as Material from "@mui/material"; // only package i used
import { useState } from "react";
import {styles} from './formStyle'

function Validations(){
    const [name, setName] = useState({ value : '', error : false })
    const [email, setEmail] = useState({ value : '', error : false })
    const [phone, setPhone] = useState({ value : '', error : false })
    const [aadhar, setAadhar] = useState({ value : '', error : false })
    const [panCard, setPanCard] = useState({ value : '', error : false })

    const emailValidation = (e) => {
        setEmail(prev=> ({...prev, value : e.target.value}))
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        if(e.target.value.match(emailRegex)){
            setEmail(prev=> ({...prev, error : false}))
        }else{
            setEmail(prev=> ({...prev, error : true}))
        }
    }

    const phoneValidation = (e) => {
        setPhone(prev=> ({...prev, value : e.target.value}))
        const phoneRegex = /^[6789]\d{9}$/;
        if(e.target.value.match(phoneRegex)){
            setPhone(prev=> ({...prev, error : false}))
        }else{
            setPhone(prev=> ({...prev, error : true}))
        }
    }

    const aadharValidation = (e) => {
        setAadhar(prev=> ({...prev, value : e.target.value}))
        const aadharRegex = /^\d{12}$/;
        if(e.target.value.match(aadharRegex)){
            setAadhar(prev=> ({...prev, error : false}))
        }else{
            setAadhar(prev=> ({...prev, error : true}))
        }
    }

    const panCardValidation = (e) => {
        setPanCard(prev=> ({...prev, value : e.target.value}))
        const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
        if(e.target.value.match(panRegex)){
            setPanCard(prev=> ({...prev, error : false}))
        }else{
            setPanCard(prev=> ({...prev, error : true}))
        }
    }

    const submitForm = () => {
        if(name.value.length !== 0){
            if(email.value.length !== 0 && email.error === false){
                if(phone.value.length !== 0 && phone.error !== true){
                    if(aadhar.value.length !== 0 && aadhar.error !== true){
                        if(panCard.value.length !== 0 && panCard.error !== true){
                            setName(prev=> ({...prev, value : ''}))
                            setEmail(prev=> ({...prev, value : ''}))
                            setPhone(prev=> ({...prev, value : ''}))
                            setAadhar(prev=> ({...prev, value : ''}))
                            setPanCard(prev=> ({...prev, value : ''}))
                            alert("Submitted Successfully");
                        }
                    }
                }
            }
        }
    }

    return(
        <Material.Box sx={styles.main} >
            <Material.Paper elevation={20} sx={styles.form}>
                <Material.Typography variant="h4">Fill Out this form</Material.Typography>
                <Material.Box sx={styles.inputBox}>
                    <Material.TextField sx={styles.input} onChange={e=> setName(prev=> ({...prev, value : e.target.value}))} value={name.value} label="Name" variant="standard" />
                </Material.Box>
                <Material.Box sx={styles.inputBox}>
                    <Material.TextField onChange={e => emailValidation(e)} value={email.value} sx={styles.input} label="Email" variant="standard" helperText={email.error ? <Material.Typography sx={styles.helperTxt}>
                        Not Valid
                    </Material.Typography> : ''} />
                </Material.Box>
                <Material.Box sx={styles.inputBox}>
                    <Material.TextField onChange={e => phoneValidation(e)} value={phone.value} sx={styles.input} label="Phone" variant="standard" helperText={phone.error ? <Material.Typography sx={styles.helperTxt}>
                        Not Valid
                    </Material.Typography> : ''} />
                </Material.Box>
                <Material.Box sx={styles.inputBox}>
                    <Material.TextField onChange={e => aadharValidation(e)} value={aadhar.value} sx={styles.input} label="Aadhar Number" variant="standard" helperText={aadhar.error ? <Material.Typography sx={styles.helperTxt}>
                        Not Valid
                    </Material.Typography> : ''} />
                </Material.Box>
                <Material.Box sx={styles.inputBox}>
                    <Material.TextField onChange={e => panCardValidation(e)} value={panCard.value} sx={styles.input} label="Pan Card Number" variant="standard" helperText={panCard.error ? <Material.Typography sx={styles.helperTxt}>
                        Not Valid
                    </Material.Typography> : ''} />
                </Material.Box>
                <Material.Box sx={{marginTop : '20px'}}>
                    <Material.Button onClick={submitForm} variant="contained">Submit</Material.Button>
                </Material.Box>
            </Material.Paper>
        </Material.Box>
    )
}

export default Validations